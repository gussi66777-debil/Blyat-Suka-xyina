# Calculator 400

Android Studio project, offline-first, Russian UI. Java WebView shell + local HTML/JavaScript interface.

## Build APK
1. Open this folder in Android Studio (Giraffe or newer).
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle runtime if prompted.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- The catalog contains 400 operation entries across 10 categories.
- Core arithmetic, common trig/log functions, quadratic equation steps, basic sequence pattern checks, geometry helpers, number analysis and numerical Simpson integration are implemented.
- Some advanced catalog entries are demonstrative or simplified placeholders and should be validated before relying on them for academic or engineering work.
- Sequence continuation is inherently ambiguous; the app reports candidate simple models, not a guaranteed unique answer.
- The equation solver currently handles quadratic equations; symbolic algebra, general systems and full symbolic integration are future extensions.
